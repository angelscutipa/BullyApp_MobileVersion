library;

// Una lista global accesible desde cualquier pantalla para añadir los números de serie
String nfcSerialNumbers = "";

// Opcional: Una variable estática para mantener el último escaneado
String lastScannedSerial = "";