import 'dart:developer';
import 'package:flutter_nfc_kit/flutter_nfc_kit.dart';

class NfcService {
  /// Ejecuta el proceso de escaneo y lectura de una etiqueta NFC de forma silenciosa
  Future<NFCTag?> readNfcTag() async {
    try {
      // 1. Verificar la disponibilidad del hardware en el dispositivo
      var availability = await FlutterNfcKit.nfcAvailability;
      if (availability != NFCAvailability.available) {
        throw Exception("El NFC no está disponible o está desactivado.");
      }

      // 2. Iniciar la sesión de lectura bloqueando ventanas externas del sistema operativo
      log("Buscando etiqueta NFC...");
      
      // Añadimos los parámetros de compatibilidad tecnológica. Al definir explícitamente 
      // estas tecnologías y mantener activo el 'iosAlertMessage', Android toma control exclusivo
      // (Foreground Dispatch) y evita abrir la ventana predeterminada del sistema.
      NFCTag tag = await FlutterNfcKit.poll(
        timeout: const Duration(seconds: 15),
        iosAlertMessage: "Acerca la tarjeta al lector",
        androidPlatformSound: false, // Desactiva el sonido nativo del sistema si lo deseas
        // readIso14443: true,
        readIso15693: true,
        readIso18092: true,
      );

      log("¡Etiqueta detectada! ID: ${tag.id}");
      
      // Si el tag tiene datos NDEF, léelos aquí mismo
    if (tag.ndefAvailable == true) {
      final ndefRecords = await FlutterNfcKit.readNDEFRecords();
      for (var record in ndefRecords) {
        print("Dato NDEF: ${record.basicInfoString}");
      }
    }

      return tag;
    } catch (e) {
      log("Error leyendo NFC: $e");
      rethrow;
    } finally {
      // 3. Siempre es vital cerrar la sesión para liberar el hardware inmediatamente
      // Esto le devuelve el control normal del NFC al teléfono al terminar.
      await FlutterNfcKit.finish();
    }
  }
}