import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'features/Principal/menu_web_view.dart';
import 'features/Principal/Presentacion/menu_footer.dart';
import 'features/Principal/Presentacion/side_menu.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bully App',
      debugShowCheckedModeBanner: false, // Quitamos la etiqueta debug
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late final WebViewController controller;
  bool _hasError = false; // Estado para manejar si no hay internet
  bool _isLoading = true; // NUEVO: Estado para manejar la pantalla de carga inicial e interna
  final String _targetUrl = 'https://bullyapp.com.pe/';

  @override
  void initState() {
    super.initState();
    _initWebViewController();
  }

  void _initWebViewController() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {},
          onPageStarted: (String url) {
            setState(() {
              _hasError = false; // Reiniciamos el estado al intentar cargar de nuevo
              _isLoading = true;  // NUEVO: Activamos el panel de carga cuando inicia la navegación
            });
          },
          onPageFinished: (String url) {
            setState(() {
              _isLoading = false; // NUEVO: Ocultamos el panel de carga cuando el renderizado es óptimo
            });

            // Inyectamos JavaScript al terminar de cargar para bloquear el zoom táctil
            controller.runJavaScript('''
              var meta = document.createElement('meta');
              meta.name = 'viewport';
              meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
              document.getElementsByTagName('head')[0].appendChild(meta);
            ''');
            controller.runJavaScript(r'''
            (() => {

              function removeButton() {
                document.querySelectorAll('button').forEach(btn => {
                  if (btn.textContent.includes('Descargar App')) {
                    btn.remove();
                  }
                });
              }

              removeButton();

              new MutationObserver(removeButton).observe(document.body, {
                childList: true,
                subtree: true
              });

            })();
            ''');
          },
          onHttpError: (HttpResponseError error) {},
          onWebResourceError: (WebResourceError error) {
            // Códigos de error de falta de conexión estándar (Android: -2, iOS: -1009)
            if (error.errorCode == -2 || 
                error.errorCode == -1009 || 
                error.description.contains('ERR_INTERNET_DISCONNECTED') ||
                error.description.contains('ERR_NAME_NOT_RESOLVED')) {
              setState(() {
                _hasError = true;
                _isLoading = false; // NUEVO: Desactivamos el loader si ocurre un error para mostrar el aviso
              });
            }
          },
          onNavigationRequest: (NavigationRequest request) {
            if (request.url.startsWith('https://www.youtube.com/')) {
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(_targetUrl));
  }

  // Método para forzar la recarga del WebView una vez regrese la conexión
  void _retryConnection() {
    setState(() {
      _hasError = false;
      _isLoading = true; // NUEVO: Aseguramos que vuelva a salir el loader al reintentar
    });
    controller.loadRequest(Uri.parse(_targetUrl));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 21, 21, 23), // Color de fondo uniforme oscuro
      endDrawer: SideMenu(controller: controller),
      endDrawerEnableOpenDragGesture: true,
      appBar: AppBar(
        backgroundColor: Colors.grey,
        toolbarHeight: 0,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Si NO hay error mostramos la web (con su capa Stack de carga), si SÍ hay error mostramos el aviso personalizado
          Expanded(
            child: !_hasError 
                ? Stack(
                    children: [
                      // Capa Base: El sitio web real
                      WebViewSection(controller: controller),
                      
                      // Capa Superior: Panel flotante condicional
                      if (_isLoading) _buildLoadingWidget(),
                    ],
                  )
                : _buildNoInternetWidget(),
          ),
        ],
      ),
      // floatingActionButton: MenuFooter(controller: controller),
      bottomSheet: MenuFooter(controller: controller),
      // bottomNavigationBar: MenuFooter(controller: controller),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  // NUEVO: Panel de carga diseñado con la misma estética oscura y dorada de tu App
  Widget _buildLoadingWidget() {
    return Container(
      color: const Color.fromARGB(255, 21, 21, 23), // Fondo oscuro idéntico para evitar parpadeos
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFFD700)), // Dorado corporativo
              strokeWidth: 3,
            ),
            SizedBox(height: 18),
            Text(
              "Cargando...",
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget personalizado nativo para interceptar la pantalla fea de "Sin Internet"
  Widget _buildNoInternetWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.wifi_off_rounded,
              size: 74,
              color: Colors.grey[600],
            ),
            const SizedBox(height: 20),
            const Text(
              "¡Uy! Sin conexión a internet",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// import 'dart:async';
// import 'dart:io' show Platform, sleep;

// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_nfc_kit/flutter_nfc_kit.dart';
// import 'package:logging/logging.dart';
// import 'package:ndef/ndef.dart' as ndef;
// import 'package:ndef/utilities.dart';

// // import 'ndef_record/raw_record_setting.dart';
// // import 'ndef_record/text_record_setting.dart';
// // import 'ndef_record/uri_record_setting.dart';


// void main() {
//   Logger.root.level = Level.ALL; // defaults to Level.INFO
//   Logger.root.onRecord.listen((record) {
//     print('${record.level.name}: ${record.time}: ${record.message}');
//   });
//   runApp(MaterialApp(theme: ThemeData(useMaterial3: true), home: MyApp()));
// }

// class MyApp extends StatefulWidget {
//   const MyApp({super.key});

//   @override
//   State createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> with SingleTickerProviderStateMixin {
//   String _platformVersion = '';
//   NFCAvailability _availability = NFCAvailability.not_supported;
//   NFCTag? _tag;
//   String? _result, _writeResult, _mifareResult;
//   late TabController _tabController;
//   List<ndef.NDEFRecord>? _records;

//   @override
//   void dispose() {
//     _tabController.dispose();
//     super.dispose();
//   }

//   @override
//   void initState() {
//     super.initState();
//     if (!kIsWeb) {
//       _platformVersion =
//           '${Platform.operatingSystem} ${Platform.operatingSystemVersion}';
//     } else {
//       _platformVersion = 'Web';
//     }
//     initPlatformState();
//     _tabController = TabController(length: 2, vsync: this);
//     _records = [];
//     FlutterNfcKit.tagStream.listen((tag) {
//       setState(() {
//         _tag = tag;
//         print(_tag);
//       });
//     });
//   }

//   // Platform messages are asynchronous, so we initialize in an async method.
//   Future<void> initPlatformState() async {
//     NFCAvailability availability;
//     try {
//       availability = await FlutterNfcKit.nfcAvailability;
//     } on PlatformException {
//       availability = NFCAvailability.not_supported;
//     }

//     // If the widget was removed from the tree while the asynchronous platform
//     // message was in flight, we want to discard the reply rather than calling
//     // setState to update our non-existent appearance.
//     if (!mounted) return;

//     setState(() {
//       // _platformVersion = platformVersion;
//       _availability = availability;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(
//             title: const Text('NFC Flutter Kit Example App'),
//             bottom: TabBar(
//               tabs: <Widget>[
//                 Tab(text: 'Read'),
//                 Tab(text: 'Write'),
//               ],
//               controller: _tabController,
//             )),
//         body: TabBarView(controller: _tabController, children: <Widget>[
//           Scrollbar(
//               child: SingleChildScrollView(
//                   child: Center(
//                       child: Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           children: <Widget>[
//                 const SizedBox(height: 20),
//                 Text('Running on: $_platformVersion\nNFC: $_availability'),
//                 const SizedBox(height: 10),
//                 ElevatedButton(
//                   onPressed: () async {
//                     try {
//                       NFCTag tag = await FlutterNfcKit.poll();
//                       setState(() {
//                         _tag = tag;
//                       });
//                       await FlutterNfcKit.setIosAlertMessage(
//                           "Working on it...");
//                       _mifareResult = null;
//                       if (tag.standard == "ISO 14443-4 (Type B)") {
//                         String result1 =
//                             await FlutterNfcKit.transceive("00B0950000");
//                         String result2 = await FlutterNfcKit.transceive(
//                             "00A4040009A00000000386980701");
//                         setState(() {
//                           _result = '1: $result1\n2: $result2\n';
//                         });
//                       } else if (tag.type == NFCTagType.iso18092) {
//                         String result1 =
//                             await FlutterNfcKit.transceive("060080080100");
//                         setState(() {
//                           _result = '1: $result1\n';
//                         });
//                       } else if (tag.ndefAvailable ?? false) {
//                         var ndefRecords = await FlutterNfcKit.readNDEFRecords();
//                         var ndefString = '';
//                         for (int i = 0; i < ndefRecords.length; i++) {
//                           ndefString += '${i + 1}: ${ndefRecords[i]}\n';
//                         }
//                         setState(() {
//                           _result = ndefString;
//                         });
//                       } else if (tag.type == NFCTagType.webusb) {
//                         var r = await FlutterNfcKit.transceive(
//                             "00A4040006D27600012401");
//                         print(r);
//                       }
//                     } catch (e) {
//                       setState(() {
//                         _result = 'error: $e';
//                       });
//                     }

//                     // Pretend that we are working
//                     if (!kIsWeb) sleep(Duration(seconds: 1));
//                     await FlutterNfcKit.finish(iosAlertMessage: "Finished!");
//                   },
//                   child: Text('Start polling'),
//                 ),
//                 const SizedBox(height: 10),
//                 Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 20),
//                     child: _tag != null
//                         ? Text(
//                             'ID: ${_tag!.id}\nStandard: ${_tag!.standard}\nType: ${_tag!.type}\nATQA: ${_tag!.atqa}\nSAK: ${_tag!.sak}\nHistorical Bytes: ${_tag!.historicalBytes}\nProtocol Info: ${_tag!.protocolInfo}\nApplication Data: ${_tag!.applicationData}\nHigher Layer Response: ${_tag!.hiLayerResponse}\nManufacturer: ${_tag!.manufacturer}\nSystem Code: ${_tag!.systemCode}\nDSF ID: ${_tag!.dsfId}\nNDEF Available: ${_tag!.ndefAvailable}\nNDEF Type: ${_tag!.ndefType}\nNDEF Writable: ${_tag!.ndefWritable}\nNDEF Can Make Read Only: ${_tag!.ndefCanMakeReadOnly}\nNDEF Capacity: ${_tag!.ndefCapacity}\nMifare Info:${_tag!.mifareInfo}\nTransceive Result:\n$_result\n\nBlock Message:\n$_mifareResult')
//                         : const Text('No tag polled yet.')),
//               ])))),
//           // Center(
//           //   child: Column(
//           //       mainAxisAlignment: MainAxisAlignment.start,
//           //       children: <Widget>[
//           //         const SizedBox(height: 20),
//           //         Row(
//           //           mainAxisAlignment: MainAxisAlignment.spaceAround,
//           //           children: <Widget>[
//           //             ElevatedButton(
//           //               onPressed: () async {
//           //                 if (_records!.isNotEmpty) {
//           //                   try {
//           //                     NFCTag tag = await FlutterNfcKit.poll();
//           //                     setState(() {
//           //                       _tag = tag;
//           //                     });
//           //                     if (tag.type == NFCTagType.mifare_ultralight ||
//           //                         tag.type == NFCTagType.mifare_classic ||
//           //                         tag.type == NFCTagType.iso15693) {
//           //                       await FlutterNfcKit.writeNDEFRecords(_records!);
//           //                       setState(() {
//           //                         _writeResult = 'OK';
//           //                       });
//           //                     } else {
//           //                       setState(() {
//           //                         _writeResult =
//           //                             'error: NDEF not supported: ${tag.type}';
//           //                       });
//           //                     }
//           //                   } catch (e, stacktrace) {
//           //                     setState(() {
//           //                       _writeResult = 'error: $e';
//           //                     });
//           //                     print(stacktrace);
//           //                   } finally {
//           //                     await FlutterNfcKit.finish();
//           //                   }
//           //                 } else {
//           //                   setState(() {
//           //                     _writeResult = 'error: No record';
//           //                   });
//           //                 }
//           //               },
//           //               child: Text("Start writing"),
//           //             ),
//           //             ElevatedButton(
//           //               onPressed: () {
//           //                 showDialog(
//           //                     context: context,
//           //                     builder: (BuildContext context) {
//           //                       return SimpleDialog(
//           //                           title: Text("Record Type"),
//           //                           children: <Widget>[
//           //                             SimpleDialogOption(
//           //                               child: Text("Text Record"),
//           //                               onPressed: () async {
//           //                                 Navigator.pop(context);
//           //                                 final result = await Navigator.push(
//           //                                     context, MaterialPageRoute(
//           //                                         builder: (context) {
//           //                                   return null;
//           //                                 }));
//           //                                 if (result != null) {
//           //                                   if (result is ndef.TextRecord) {
//           //                                     setState(() {
//           //                                       _records!.add(result);
//           //                                     });
//           //                                   }
//           //                                 }
//           //                               },
//           //                             ),
//           //                             SimpleDialogOption(
//           //                               child: Text("Uri Record"),
//           //                               onPressed: () async {
//           //                                 Navigator.pop(context);
//           //                                 final result = await Navigator.push(
//           //                                     context, MaterialPageRoute(
//           //                                         builder: (context) {
//           //                                   return NDEFUriRecordSetting();
//           //                                 }));
//           //                                 if (result != null) {
//           //                                   if (result is ndef.UriRecord) {
//           //                                     setState(() {
//           //                                       _records!.add(result);
//           //                                     });
//           //                                   }
//           //                                 }
//           //                               },
//           //                             ),
//           //                             SimpleDialogOption(
//           //                               child: Text("Raw Record"),
//           //                               onPressed: () async {
//           //                                 Navigator.pop(context);
//           //                                 final result = await Navigator.push(
//           //                                     context, MaterialPageRoute(
//           //                                         builder: (context) {
//           //                                   return NDEFRecordSetting();
//           //                                 }));
//           //                                 if (result != null) {
//           //                                   if (result is ndef.NDEFRecord) {
//           //                                     setState(() {
//           //                                       _records!.add(result);
//           //                                     });
//           //                                   }
//           //                                 }
//           //                               },
//           //                             ),
//           //                           ]);
//           //                     });
//           //               },
//           //               child: Text("Add record"),
//           //             )
//           //           ],
//           //         ),
//           //         const SizedBox(height: 10),
//           //         Text('Result: $_writeResult'),
//           //         const SizedBox(height: 10),
//           //         Expanded(
//           //           flex: 1,
//           //           child: ListView(
//           //               shrinkWrap: true,
//           //               children: List<Widget>.generate(
//           //                   _records!.length,
//           //                   (index) => GestureDetector(
//           //                         child: Padding(
//           //                             padding: const EdgeInsets.all(10),
//           //                             child: Text(
//           //                                 'id:${_records![index].idString}\ntnf:${_records![index].tnf}\ntype:${_records![index].type?.toHexString()}\npayload:${_records![index].payload?.toHexString()}\n')),
//           //                         onTap: () async {
//           //                           final result = await Navigator.push(context,
//           //                               MaterialPageRoute(builder: (context) {
//           //                             return NDEFRecordSetting(
//           //                                 record: _records![index]);
//           //                           }));
//           //                           if (result != null) {
//           //                             if (result is ndef.NDEFRecord) {
//           //                               setState(() {
//           //                                 _records![index] = result;
//           //                               });
//           //                             } else if (result is String &&
//           //                                 result == "Delete") {
//           //                               _records!.removeAt(index);
//           //                             }
//           //                           }
//           //                         },
//           //                       ))),
//           //         ),
//           //       ]),
//           // )
//         ]),
//       ),
//     );
//   }
// }