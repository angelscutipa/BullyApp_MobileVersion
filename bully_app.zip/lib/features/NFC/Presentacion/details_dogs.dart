import 'package:flutter/material.dart';

class DetailsDogs extends StatelessWidget {
  const DetailsDogs({super.key});

  @override
  Widget build(BuildContext context) {
    // Colores de la paleta premium de tu app
    const Color scaffoldBgColor = Color(0xFF111112);
    const Color cardBgColor = Color(0xFF1C1C1E);
    const Color accentColor = Color(0xFFFFD700); // Dorado/Amarillo activo
    const Color secondaryTextColor = Colors.grey;

    return Scaffold(
      backgroundColor: scaffoldBgColor,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. Imagen de Cabecera con Botón de Regresar
            Stack(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height * 0.45,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(32),
                      bottomRight: Radius.circular(32),
                    ),
                    image: DecorationImage(
                      image: NetworkImage(
                        'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=1000&auto=format&fit=crop', // Reemplazar por tu asset o red url
                      ),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                // Botón de Regresar Flotante (Alineado con el diseño iOS/Moderno)
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: CircleAvatar(
                      backgroundColor: Colors.black.withOpacity(0.5),
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back, color: Colors.white),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            // Contenido de los Detalles
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 2. Fila de Nombre, Edad y Género
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Kobe',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'American Bully',
                            style: TextStyle(
                              color: const Color.fromARGB(255, 255, 115, 0).withOpacity(0.8),
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      // Edad y Género insignia
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          const Text(
                            '2 Años',
                            style: TextStyle(
                              color: accentColor,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: const [
                              Icon(Icons.male, color: Colors.blue, size: 18),
                              SizedBox(width: 4),
                              Text(
                                'Macho',
                                style: TextStyle(color: Colors.white70, fontSize: 14),
                              ),
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: 8),

                  // 3. Botones de Acción Rápida (Estilo Redondos)
                  SizedBox(
                    width: double.infinity, // Asegura que ocupe todo el ancho de la pantalla
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween, // Distribuye los bloques a los extremos
                      children: [
                        // Bloque de Inicio: Ícono de persona y Nombre
                        Row(
                          children: [
                            Icon(
                              Icons.person_outline, // O Icons.person si lo prefieres relleno
                              color: Colors.white,  // Ajusta al color de tu tema
                              size: 24,
                            ),
                            const SizedBox(width: 8), // Espaciado entre el ícono y el nombre
                            Text(
                              "Paul García Yucra", // Aquí pones la variable o texto del nombre
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),

                        // Bloque del Final: Tus 2 botones de acción existentes
                        Row(
                          children: [
                            // _buildActionButton(Icons.account_tree_outlined, "Árbol", () {}),
                            const SizedBox(width: 12), // Espaciado entre los dos botones finales
                            _buildActionButton(Icons.location_on_outlined, "Mapa", () {}),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 8),

                  // 4. Grid de Atributos Clave (2x2)
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 2.3,
                    children: [
                      _buildAttributeCard(const Color.fromARGB(255, 11, 39, 25), const Color.fromARGB(255, 0, 255, 136), 'Teléfono propietario', '+51997612277'),
                      _buildAttributeCard(const Color.fromARGB(255, 13, 28, 41), const Color.fromARGB(255, 0, 225, 255), 'Registro', 'ABKC Registered'),
                      _buildAttributeCard(const Color.fromARGB(255, 36, 16, 5), const Color.fromARGB(255, 255, 166, 0), 'Microchip', '9810234...'),
                      _buildAttributeCard(const Color.fromARGB(255, 39, 28, 5), accentColor, 'Criadero', 'LA RUTA BULLS'),
                    ],
                  ),

                  const SizedBox(height: 8),

                  // // 5. Sección de Biografía
                  // const Text(
                  //   'Biografía',
                  //   style: TextStyle(
                  //     color: Colors.white,
                  //     fontSize: 20,
                  //     fontWeight: FontWeight.bold,
                  //   ),
                  // ),
                  // const SizedBox(height: 10),
                  // const Text(
                  //   'Kobe es un ejemplar excepcional de American Bully con una estructura ósea impecable, un temperamento dócil y equilibrado. Ideal para exhibiciones y convivencia familiar. Cuenta con todas sus vacunas y controles al día.',
                  //   style: TextStyle(
                  //     color: secondaryTextColor,
                  //     fontSize: 14,
                  //     height: 1.5,
                  //   ),
                  // ),

                  // const SizedBox(height: 35),

                  // 6. Botón de Acción Principal Inferior
                  Row(
                    children: [
                      // Botón 1: Perfil de Propietario
                      Expanded(
                        child: SizedBox(
                          height: 54,
                          child: ElevatedButton(
                            onPressed: () {
                              // Acción al presionar el botón de Perfil de Propietario
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accentColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 0,
                            ),
                            child: const Text(
                              'Perfil de Propietario',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 14, // Ajustado ligeramente para que quepa bien en pantallas chicas
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                      
                      const SizedBox(width: 12), // Espaciado elegante entre los dos botones

                      // Botón 2: Perfil del Ejemplar
                      Expanded(
                        child: SizedBox(
                          height: 54,
                          child: ElevatedButton(
                            onPressed: () {
                              // Acción al presionar el botón de Perfil del Ejemplar
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: accentColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              elevation: 0,
                            ),
                            child: const Text(
                              'Perfil del Ejemplar',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 14, // Ajustado para mantener la simetría visual
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24), // Margen de seguridad inferior
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget Auxiliar para construir los botones redondos pequeños
  Widget _buildActionButton(IconData icon, String tooltip, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(50),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF1C1C1E),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white10),
        ),
        child: Icon(
          icon,
          color: Colors.white,
          size: 22,
        ),
      ),
    );
  }

  // Widget Auxiliar para construir las tarjetas de los atributos (2x2)
  Widget _buildAttributeCard(Color bgColor, Color accent, String title, String value) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: accent.withOpacity(0.4), // Usamos el accent con opacidad para que sea fino
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.grey,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}