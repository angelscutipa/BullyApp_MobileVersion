import 'package:flutter/material.dart';
import 'package:flutter_nfc_kit/flutter_nfc_kit.dart';
import 'package:bully_app/core/global_variables.dart' as globals;
import 'package:bully_app/core/services/nfc_services.dart';

// Importa tus nuevos componentes modulares
import 'package:bully_app/features/NFC/Presentacion/bully_yellow_button.dart';
import 'package:bully_app/features/NFC/Presentacion/hero_card.dart';
import 'package:bully_app/features/NFC/Presentacion/details_dogs.dart';

class BullyChipSearchDialog extends StatefulWidget {
  const BullyChipSearchDialog({super.key});

  @override
  State<BullyChipSearchDialog> createState() => _BullyChipSearchDialogState();
}

class _BullyChipSearchDialogState extends State<BullyChipSearchDialog> {
  final TextEditingController _searchController = TextEditingController();
  final NfcService _nfcService = NfcService();
  bool _isScanning = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SafeArea(
        child: Column(
          children: [
            // Botón de cerrar de la barra superior
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () => Navigator.of(context).pop(),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.grey[900],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.close, color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ),
            
            // Cuerpo del Dialog
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 20),
                    
                    // 1. Componente de tarjeta animada extraído
                    const HeroCard(),

                    const SizedBox(height: 32),

                    // 2. Componente de botón NFC extraído
                    BullyYellowButton(
                      icon: Icons.nfc,
                      label: 'Iniciar escaneo',
                      onTap: () async {
                        if (_isScanning) return;
                        await _handleNfcRead();
                      },
                    ),

                    const SizedBox(height: 32),

                    // Divisor de diseño
                    Row(
                      children: [
                        Expanded(child: Container(height: 1, color: Color.fromARGB(90, 255, 140, 0))),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: Icon(Icons.circle_outlined, color: Color(0xFFFF8C00), size: 12),
                        ),
                        Expanded(child: Container(height: 1, color: Color.fromARGB(90, 255, 140, 0))),
                      ],
                    ),

                    const SizedBox(height: 32),

                    // Formulario de Búsqueda Manual
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: const Color(0xFF111111),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Color.fromARGB(90, 255, 140, 0)),
                      ),
                      child: Column(
                        children: [
                          TextFormField(
                            style: const TextStyle(
                                color: Color.fromARGB(255, 255, 255, 255), // Color del texto que escribe el usuario
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            decoration: InputDecoration(
                              hintText: 'Ej: BCHIP123456',
                              // Borde cuando NO está seleccionado
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 37, 37, 37),
                                  width: 1.5,
                                ),
                              ),

                              // Borde cuando está seleccionado (focus)
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(
                                  color: Color.fromARGB(197, 255, 123, 0),
                                  width: 1,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          
                          // 3. Componente de botón Buscar extraído
                          BullyYellowButton(
                            icon: Icons.qr_code_scanner,
                            label: 'Buscar',
                            onTap: () {
                              final code = _searchController.text.trim();
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const DetailsDogs(),
                                ),
                              );
                              if (code.isNotEmpty) {
                                debugPrint('Buscando de forma manual: $code');
                              }
                            },
                          ),
                          const SizedBox(height: 16),
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 250),
                            child: _isScanning
                                ? Container(
                                    key: const ValueKey('scanEffect'),
                                    width: double.infinity,
                                    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF141414),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(color: const Color(0xFF333333)),
                                    ),
                                    child: Column(
                                      children: [
                                        LinearProgressIndicator(
                                          minHeight: 4,
                                          backgroundColor: const Color(0xFF1A1A1A),
                                          valueColor: const AlwaysStoppedAnimation(Color(0xFFFF8C00)),
                                        ),
                                        const SizedBox(height: 10),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: const [
                                            Icon(Icons.nfc, color: Color(0xFFFF8C00), size: 16),
                                            SizedBox(width: 8),
                                            Text(
                                              'Escaneando chip...',
                                              style: TextStyle(color: Colors.white70, fontSize: 14),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  )
                                : const SizedBox.shrink(),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Lógica del lector de hardware NFC
  Future<void> _handleNfcRead() async {
    setState(() => _isScanning = true);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Escaneando... Acerca el tag')),
    );

    try {
      NFCTag? tag = await _nfcService.readNfcTag();

      if (tag != null) {
        final formattedId = tag.id.replaceAllMapped(RegExp(r'.{2}'), (match) => '${match.group(0)}:');
        final savedId = formattedId.endsWith(':') ? formattedId.substring(0, formattedId.length - 1) : formattedId;

        setState(() {
          globals.nfcSerialNumbers = savedId;
          globals.lastScannedSerial = savedId;
        });

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const DetailsDogs(),
          ),
        );

        final result = '¡Lectura Exitosa!\nID (UID): $savedId\nTipo: ${tag.type.name}';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result)));
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al leer: $error'), backgroundColor: Colors.redAccent),
      );
    } finally {
      setState(() => _isScanning = false);
    }
  }
}